########################################### START OF PROGRAM ###########################################################
'''
@author: <sauveer.goel@soprasteria.com>
'''
########################################################################################################################
# Implementation: Relationship Microservice Environment Setup File [Ontofy.kit]
# Description:    This script enables to automatically download the wordnet corpus required for Lemmatization used 
#                 by the Relationship Microservice [Ontofy.kit]
########################################################################################################################


###########################################Start of Import Statements###################################################
import nltk # to use the download function for downloading the required corpus
###########################################End of Import Statements#####################################################

# Downloading the wordnet data to be used for Lemmatization
nltk.download('wordnet')
nltk.download('punkt')
########################################### END OF PROGRAM #############################################################