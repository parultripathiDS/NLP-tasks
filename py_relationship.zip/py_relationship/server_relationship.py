########################################### START OF PROGRAM ###########################################################
"""
@author: <sauveer.goel@soprasteria.com>
"""
########################################################################################################################
# Implementation: Relationship Microservice [Ontofy.kit]
# Description:    The following implementation caters to the functionalities defined under the scope of relationship 
#                 processing for Ontofy.kit
#                 The functionalities are as follows:
#                 - Relationship Extraction V2 from a set of documents [/v2/relInit]
#                 - Relationship Extraction Progress Tracker [/v1/relprogress]
#                 - Relationship-Type Assignment V1 for a set of keywords [/v1/propertyAssignment]
#                 - Relationship-Type Assignment V2 for a set of keywords [/v2/propertyAssignment]
#                 - Relationship-Type Assignment Progress Tracker [/v1/propertyprogress]
########################################################################################################################


###########################################Start of Import Statements###################################################
import sys
from pymongo import MongoClient                  # to perform operation related to MongoDB
import nltk
from nltk.tokenize import PunktSentenceTokenizer # to split the documents into sentences
import json                                      # to convert the results into json dictionaries and 
                                                 #     write them in MongoDB
import time                                      # to halt the program
import csv                                       # to read the list of relationships extracted from the OWL files
import requests                                  # to perform external API Calls
import re                                        # to perform regular expression processing
from flask import Flask                          # to deploy as a flask service
from flask import request                        # to be able to read the incoming requests
from flask import jsonify                        # to parse the response as JSON
from flask import abort                          # to close the connection with the client with an error code
from flask_cors import CORS                      # to enable Cross-Origin Resource Sharing
from practnlptools.tools import Annotator        # to perform sementic role labelling
from nltk.stem import WordNetLemmatizer          # to execute lemmatization on relationships extracted
import urllib2                                   # to perform External API Calls
import logging                                   # to perform logging
from config import Config                        # importing the configrable variables
from dependency_parse import annotate_text       # to perform dependency parse
from itertools import chain
import string
###########################################End of Import Statements#####################################################


# Initializing Flask Application
app = Flask(__name__)          # 'app' refers to initialized Flask App
CORS(app)                      # to enable CORS for the services
app.config.from_object(Config) # attaching the configurations to the flask app

# Configuring Logs
logging.basicConfig(filename=app.config['LOG_FILENAME'], filemode='a',format=app.config['LOG_FORMAT']\
    , datefmt=app.config['LOG_DATE_FORMAT'], level=app.config['LOG_LEVEL'])


###########################################Start of Relationship Extraction Progress Tracker############################
########################################################################################################################
# Description:   Relationship Extraction Progress Tracker API takes an Ontofy Project ID as input, fetches the progress
#                of the Relationship Extraction API from MongoDB's Collection: 'relProgress' and returns the  
#                retrieved progress
# Usage:         The API is a POST method that takes as input a JSON in the body of the request and also returns a JSON
# API URL:       http://<hostname>:<port>/v1/relprogress
# Content-Type:  application/json
# Request Data:  {"p_id":<Ontofy Project ID>}
# Response Data: {"status":"success","result":{"progress":<PROGRESS as string>}} OR {"status":"error","result":""}
########################################################################################################################

# Declaration and definition of the Web Service
@app.route('/v1/relprogress',methods=['GET'])
def relationshipExtractionProgress():
    try:
        # Initializing  connection to MongoDB Server
        db = MongoClient([app.config['MONGODB_SERVER_URL']])
        logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - relprogress: Connected to MongoDB")

        # defining database as 'Ontology' and collection as 'relProgress'
        progressDB = db.Ontology.relProgress 

        # Retrieving Ontofy Project ID from the request data
        p_id = request.args["p_id"]
        logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - relprogress: read p_id: " + p_id)

        # Retrieving progress of Relationship Extraction API corresponding to the supplied Ontofy Project ID
        currentProgress = progressDB.find_one({"p_id":p_id}) 
        logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - relprogress: fetched progress from MongoDB: %s%",currentProgress["progress"])

        # sending the response and closing the connection successfully
        return jsonify({"status":"success","result":{"progress":currentProgress["progress"]}}),201

    except Exception as e:
        logging.error(e)
        return jsonify({"status":"error","result":""}),500

###########################################End of Relationship Extraction Progress Tracker##############################


###########################################Start of Relationship-Type Assignment Progress Tracker#######################
########################################################################################################################
# Description:   Relationship-Type Assignment Progress Tracker API takes an Ontofy Project ID as input, fetches the 
#                progress of the Relationship-Type Assignment API from MongoDB's Collection: 'propProgress' and returns 
#                the retrieved progress
# Usage:         The API is a POST method that takes as input a JSON in the body of the request and also returns a JSON
# API URL:       http://<hostname>:<port>/v1/propertyprogress
# Content-Type:  application/json
# Request Data:  {"p_id":<Ontofy Project ID>}
# Response Data: {"status":"success","result":{"progress":<PROGRESS as string>}} OR {"status":"error","result":""}
########################################################################################################################

# Declaration and definition of the Web Service
@app.route('/v1/propertyprogress' ,methods=['GET'])
def propertyAssingmentProgress():
    try:
        # Initializing  connection to MongoDB Server
        db = MongoClient([app.config['MONGODB_SERVER_URL']])
        logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - propertyprogress: Connected to MongoDB")

        # defining database as 'Ontology' and collection as 'propProgress'
        progressDB = db.Ontology.propProgress 

        # Retrieving Ontofy Project ID from the request data
        p_id = request.args["p_id"]
        logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - propertyprogress: read p_id: " + p_id)

        # Retrieving progress of Relationship Extraction API corresponding to the supplied Ontofy Project ID
        currentProgress = progressDB.find_one({"p_id":p_id}) 
        logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - propertyprogress: fetched progress from MongoDB: %s%",currentProgress["progress"])

        # sending the response and closing the connection successfully
        return jsonify({"status":"success","result":{"progress":currentProgress["progress"]}}),201
        
    except Exception as e:
        logging.error(e)
        return jsonify({"status":"error","result":""}),500
###########################################End of Relationship-Type Assignment Progress Tracker#########################


###########################################Start of Relationship-Type Assignment V2 Web Service#########################
########################################################################################################################
# Description:   Relationship-Type Assignment Web Service API takes an Ontofy Project ID and Ontofy User ID as input.
#                The service then calls the DB to fetch submitted relations and takes each one of the to wikidata
#                API in search for a type. It writes the relations tagged with suggested types into the DB directly and
#                returns a status.
# Usage:         The API is a POST method that takes as input a JSON in the body of the request and also returns a JSON
# API URL:       http://<hostname>:<port>/v2/propertyAssignment
# Content-Type:  application/json
# Request Data:  {"p_id":<Ontofy Project ID>,"user_id":<Ontofy User ID>}
# Response Data: {"status":"success","result":""} OR {"status":"error","result":""}
########################################################################################################################

# Declaration and definition of the Web Service
@app.route('/v2/propertyAssignment',methods=['POST'])
def propertyAssignment():
    info = request.json

    # Checking if data is received or not
    if not info:
        logging.error("- " + info["p_id"] + " - " + info["user_id"] + " - propertyAssignment: data not received   in the body or as JSON")
        abort(400) # if data is not received then abort the execution of the API
    else: # if data is received  
        relations = [] # stores the list of relation retrieved from the DB
        parent_properties = [] # list populated for [relation,parent_property]
        count = 1 #progress calculation
        try:
            # Initializing  the DB
            db = MongoClient([app.config['MONGODB_SERVER_URL']])
            relationDB = db.Ontology.tempjsons
            logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - propertyAssignment: Connected to the DB")

            # Initializing  progress document
            progressDB = db.Ontology.propProgress
            progress = {"progress":"0","p_id":info['p_id']}
            progressDB.insert_one(progress)
            logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - propertyAssignment: progress document initialized and stored")

            # Fetching the required data from DB
            submitted_relations = relationDB.find_one({"p_id": info['p_id'],"user_id":info['user_id'],"task":"relation"})
            logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - propertyAssignment: fetched submitted keywords from temjsons collection")
            logging.debug(submitted_relations)

            # Collecting submitted relations in variable 'property'
            relations = [submitted_relation['property']\
            for submitted_relation in submitted_relations['results']['extractedRelationship'].values()]
            logging.debug(relations)

            ############################################################################################################
            # Iterating each submitted keyword in order to search wikidata for its entity type using a combination of 
            # three wikidata request methods:
            # r1: wbsearchentities - takes as input a phrase as a string, returns a wikidata Entity ID
            # r2: wbgetclaims -      takes as input a wikidata Entity ID, returns wikidata Entity ID of property P31  
            #                        i.e. the 'instanceOf' property corresponding to the wikidata Entity ID supplied 
            # r3: wbgetentities -    takes as input a wikidata Entity ID, returns the corresponding phrase as a string
            ############################################################################################################
            '''
            logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - propertyAssignment: wikidata iterations started")

            for relation in relations:
                tempRelationMatches = [] # loop variable to store matches
                tempRelationInstanceIds = []  # loop variable to store wikidata IDs for the matches

                # Executing r1 requests
                r1 = requests.get(app.config['R1_REQUEST_URL'] + relation + "&language=en&format=json")
                logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - propertyAssignment: r1 executed")
                if r1.status_code == 200:
                    r1 = json.loads(r1.content) # converting result JSON to python dictionary type

                for entity in r1['search']: # 'search' key stores the array of matched results

                    if r1['searchinfo']['search'].lower() == entity['label'].lower(): # checking for exact matches
                        tempRelationMatches.append(entity['id'])

                for relationMatch in tempRelationMatches: # for each relevant match 

                    # Executing r2 request
                    r2 = requests.get(app.config['R2_REQUEST_URL'] + relationMatch + "&format=json&property=P31")
                    logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - propertyAssignment: r2 executed")
                    r2 = json.loads(r2.content)  #converting result JSON to python dictionary type

                    if 'P31' in r2['claims']: # checking if 'instanceOf property is available'

                        for p31 in r2['claims']['P31']:
                            tempRelationInstanceIds.append(p31['mainsnak']['datavalue']['value']['id'])

                        for relationInstance in tempRelationInstanceIds: # for each property found
                            r3 = requests.get(app.config['R3_REQUEST_URL'] + relationInstance + "&format=json")
                            logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - propertyAssignment: r3 executed")
                            r3 = json.loads(r3.content) # converting result JSON to python dictionary type

                            # if entityType is in English with description
                            if 'en' in r3['entities'][relationInstance]['labels']\
                            and 'en' in r3['entities'][relationInstance]['descriptions']:
                                # Collecting [relation,relationship_type] pairs in 'parent_properties' variable
                                parent_properties.append([relation,r3['entities'][relationInstance]['labels']['en']\
                                    ['value'],r3['entities'][relationInstance]['descriptions']['en']['value']\
                                    .replace('"','')])
                            # else if entityType is in English without description
                            elif 'en' in r3['entities'][relationInstance]['labels']:
                                parent_properties.append([relation,r3['entities'][relationInstance]\
                                    ['labels']['en']['value'],""])

                # Updating the progress of the API
                currentProgress = progressDB.find_one({"p_id":info['p_id']}) # fetching the previous progress document
                currentProgress["progress"] = str(count*100.0/len(relations)) # updating progress value
                progressDB.save(currentProgress) # updating the progress document with new value
                logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - propertyAssignment: progress updated %s%",currentProgress["progress"])
                count = count + 1

            logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - propertyAssignment: loop execution complete")
            parent_properties = [list(x) for x in set(tuple(x) for x in parent_properties)] # removing duplicates if any
            propertyTypes = [[temp[1],temp[2]] for temp in parent_properties] # converting into list of list
            propertyTypes = [list(x) for x in set(tuple(x) for x in propertyTypes)] # removing duplicates if any
            '''
            CNEntities = requests.post(app.config['CONCEPTNET_TYPES_URL'],\
                json = {"concepts":list(set(relations)),"p_id": info['p_id'], "task": "R"}).json()["types"]

            ############################################################################################################
            # Generating the result that needs to be pushed to the DB
            # Format: {
            #           "user_id":<Ontofy User ID>,
            #           "p_id":<Ontofy Project ID>,
            #           "task":"propertyAssignment",
            #           "results":{
            #                       "extractedRelationship":{ 
            #                                             "NUMERIC_INDEXES":{
            #                                                                 "property":<ENTITY STRING>
            #                                                                 "parentProperty":<ENTITY TYPE STRING>
            #                                                               },...
            #                                           },
            #                       "propertyTypeDescription":{
            #                                                "NUMERIC_INDEXES":{
            #                                                                     "propertyType":<ENTITY TYPE STRING>
            #                                                                     "description":<Desc of ENTITY TYPE>
            #                                                                   },...
            #                                               }
            #                     }
            #           }
            #
            ############################################################################################################
            logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - propertyAssignment: Output generation started")

            if len(parent_properties) > 0:
                output = '{"user_id":"' + info['user_id'] + '","p_id":"' + info['p_id']\
                + '","task":"propertyAssignment","results":{"extractedRelationship":{'
                keyitr = 1

                for relation in relations:
                    output = output + '"' + str(keyitr) + '":{"property":"' + relation + '","parentProperty":""},'
                    keyitr = keyitr + 1
                output = output[:-1] + '},"propertyTypeDescription":{'
                
                keyitr = 1
                for propertyType in propertyTypes:
                    output = output + '"' + str(keyitr) + '":{"propertyType":"' + propertyType[0] + '","description":"'\
                    + propertyType[1] + '"},'
                    keyitr = keyitr + 1
                output = output[:-1] + '}}}'

            else:  # if relationship types are not found
                output = '{"user_id":"' + info['user_id'] + '","p_id":"' + info['p_id']\
                + '","task":"propertyAssignment","results":{"extractedRelationship":{'
                keyitr = 1

                for relation in relations:
                    output = output + '"' + str(keyitr) + '":{"property":"' + relation + '","parentProperty":""},'
                    keyitr = keyitr + 1

                if len(relations) > 0:
                    output = output[:-1] + '},"propertyTypeDescription":{}}}'
                else:
                    output = output + '},"propertyTypeDescription":{}}}'

            output = json.loads(output) # converting result JSON to python dictionary type
            output["results"]["suggestedTypes"] = CNEntities
            #relationDB.remove({"p_id": info['p_id'],"user_id":info['user_id'],"task":"relation"}) # delete this on node end
            relationDB.insert_one(output) # write the new results to DB
            time.sleep(app.config['HAULT_TIME']) # halt the program
            progressDB.remove({"p_id":info['p_id']}) # delete the progress document
            logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - propertyAssignment: Exiting the service successfully")
            return jsonify({"status":"success","result":""}),201

        except Exception as e:
            logging.error(e)
            return jsonify({"status":"error","result":""}),500
###########################################End of Relationship-Type Assignment V2 Web Service###########################        


###########################################Start of Relationship-Type Assignment V1 Web Service#########################
########################################################################################################################
# Description:   Relationship-Type Assignment Web Service API takes an Ontofy Project ID and Ontofy User ID as input.
#                The service then calls the DB to fetch submitted relations and takes each one of the to wikidata
#                API in search for a type. It writes the relations tagged with suggested types into the DB directly and
#                returns a status.
# Usage:         The API is a POST method that takes as input a JSON in the body of the request and also returns a JSON
# API URL:       http://<hostname>:<port>/v1/propertyAssignment
# Content-Type:  application/json
# Request Data:  {"p_id":<Ontofy Project ID>,"user_id":<Ontofy User ID>}
# Response Data: {"status":"success","result":""} OR {"status":"error","result":""}
########################################################################################################################

# Declaration and definition of the Web Service
@app.route('/v1/propertyAssignment',methods=['POST'])
def propertyAssignmentExtraction():
    # Checking if data received  
    info = request.json
    if not info:
        logging.error("- " + info["p_id"] + " - " + info["user_id"] + " - propertyAssignment1: data not received in the body or as JSON")
        abort(400) # if data not received abort the call with HTTP error code 400

    try:
        # Initalizing Lemmatizer
        wordnet_lemmatizer = WordNetLemmatizer()
        logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - propertyAssignment1: Lemmatizer initialized")

        # Initializing DB
        db = MongoClient(['ontofy_mongodb_services:27017'])
        propertyAssignmentResults = db.Ontology.tempjsons
        propertyAssignment = db.Ontology.propertyassignments
        logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - propertyAssignment1: DB initialized")

        documents = [] # Array to store text of the document supplied

        # Fetching the docuemtns from the DB
        toBeAssinged = propertyAssignment.find_one({'docId': info["docId"]})  
        toBeAssinged = toBeAssinged["relationships"] 
        logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - propertyAssignment1: documents fetched")
        logging.debug(toBeAssinged)

        # Reading the list of relations from the corresponding OWL
        relList = urllib2.urlopen( app.config['OWL_RELATIONSHIP_CONSUMPTION_URL'] + "p_id=" + info["p_id"] + "&user_id=" + info["user_id"]).read()
        logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - propertyAssignment1: entities read from OWL using the OntologyAPI Entity Extraction call")
        relList = relList.split('\n')[1:]
        relList = relList[:-1]
        relList = [relListElement.split(',') for relListElement in relList]
        logging.debug(relList)
        # Processing and matching the OWL relations with the docuemnt Text
        rel_extracted = []

        logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - propertyAssignment1: Matching of Relations Starts")

        # Matching of relations from OWL and Reviewed results started
        for toBe in toBeAssinged:
            count = 0 # flag to check if a parent propety was found

            for rel in relList:
                logging.info(rel)

                if len(rel) > 1: # If sub-property is available
                    rel[1] = rel[1][0].upper() + rel[1][1:]      # capitalizing the first character
                    tempRels = rel[1].split(" ") 

                    # Lemmatizing the relation to its root form
                    for tempRel in tempRels:
                        tempRel = wordnet_lemmatizer.lemmatize(tempRel.lower())
                        tempRels = " ".join(tempRels)
                        tempRels = tempRels.lower()

                        # Matching the lemmatized relation with the Ontofy Reviewed Relation
                        if tempRel.find(toBe + " ") >-1:
                            rel_extracted.append(rel)
                            count = count + 1
                else: # If no sub-property is available
                    rel[0] = rel[0][0].upper() + rel[0][1:]      # capitalizing the first character
                    tempRels = re.findall("[A-Z][^A-Z]*",rel[0]) # splitting the sub-property by each capital letter

                    # Lemmatizing the relation to its root form
                    for tempRel in tempRels:
                        tempRel = wordnet_lemmatizer.lemmatize(tempRel.lower())
                        tempRels = " ".join(tempRels)
                        tempRels = tempRels.lower()

                        # Matching the lemmatized relation with the Ontofy Reviewed Relation
                        if tempRel.find(toBe + " ") >-1:
                            rel_extracted.append(rel)
                            count = count + 1
            # If no match was found then tagging it with blank parent-property
            if count == 0:
                rel_extracted.append([toBe,""])
        logging.debug(rel_extracted)
        logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - propertyAssignment1: successfully matched the relations")

        # Removing the duplicates from the list
        rel_extracted = [list(x) for x in set(tuple(x) for x in rel_extracted)]
        relationships_only = []
        for i in range(0,len(rel_extracted)):
            relationships_only.append(rel_extracted[i][0])

        CNEntities = requests.post(app.config['CONCEPTNET_TYPES_URL'],\
            json = {"concepts":list(set(relationships_only)),"p_id": info['p_id'], "task": "R"}).json()["types"]

        ################################################################################################################
        # Generating the result that needs to be pushed to the DB
        # Format: {
        #             "p_id":<ID of the project of the user>,
        #             "user_id":<ID of the User>,
        #             "task":"propertyAssignment",
        #             "results":{ 
        #                         "extractedRelationship":{ 
        #                                                 "NUMERIC_INDEXES": {
        #                                                                      "parentProperty":<type of Entity>
        #                                                                      "property":<name of Entity>
        #                                                                      },...
        #                                           },
        #                         "selectedRelationship":{} 
        #                      }
        #           }
        #
        ################################################################################################################
        logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - propertyAssignment1: Output generation initiated")
        
        output='{"p_id":"'+info["p_id"]+'","user_id":"'+info["user_id"]\
        +'","task":"propertyAssignment","results":{ "extractedRelationship":{'

        for i in range(0,len(rel_extracted)):
            if rel_extracted[i][1] != "":
                output = output + '"' + str(i+1) + '":{"parentProperty":"' + rel_extracted[i][0] + '","property":"'\
                + rel_extracted[i][1] + '"},'
            else:
                output = output + '"' + str(i+1) + '":{"parentProperty":"","property":"' + rel_extracted[i][0] + '"},'

        if len(rel_extracted)==0:
            output = output + '},"selectedRelationship": {}}}'
        else:
            output = output[:-1] + '},"selectedRelationship": {}}}'
        output = json.loads(output)
        output["results"]["suggestedTypes"] = CNEntities

        # Pushing the resutls to the DB
        propertyAssignmentResults.insert_one(output)
        logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - propertyAssignment1: closing the request successfully")
        return jsonify({"status":"success","result":""}),201

    except Exception as e:
        logging.error(e)
        return jsonify({"status":"error","result":""}),500
###########################################Start of Relationship-Type Assignment V1 Web Service#########################


###########################################Start of Relationship Extraction  Web Service################################
########################################################################################################################
# Description:   Relationship Extraction  Web Service API takes Ontofy Project ID, Ontofy User ID and target 
#                Document IDs as input. The service then calls the DB to fetch text from the supplied Document IDs.
#                Performs Sementic Role Labelling(SRL) on the text and return the results to the DB and to the user
#                returns a status.
# Usage:         The API is a POST method that takes as input a JSON in the body of the request and also returns a JSON
# API URL:       http://<hostname>:<port>/v2/relInit
# Content-Type:  application/json
# Request Data:  {"p_id":<Ontofy Project ID>,"user_id":<Ontofy User ID>,"ids":[<JSON Array of Ontofy Document IDs>]}
# Response Data: {"status":"success","result":""} OR {"status":"error","result":""}
########################################################################################################################

# Declaration and definition of the Web Service
@app.route('/v2/relInit',methods=['POST'])
def relInitv2():
    # Checking if data received  
    info = request.json
    if not info:
        logging.error("- " + info["p_id"] + " - " + info["user_id"] + " - relInit: data not received in the body or as JSON")
        abort(400) # if data not received abort the call with HTTP error code 400
    else:
        try:
            # Initializing the annotator for SRL
            annotator=Annotator() 
            logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - relInit: Annotator initialized")

            # Initializing the sentence tokenizer
            tokenizer = PunktSentenceTokenizer()
            logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - relInit: Tokenizer initialized")

            # Initializing the DB
            db = MongoClient([app.config['MONGODB_SERVER_URL']])
            relationshipResults = db.Ontology.tempjsons
            fileContent = db.Ontology.filecontents
            logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - relInit: DB initialized")

            # Intializing progress DB
            progressDB = db.Ontology.relProgress
            progress = {"progress":"0","p_id":info['p_id']}
            progressDB.insert_one(progress)
            logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - relInit: progress initialized")

            # Fetching the supplied documents and pre processing them
            documents = [] # array for storing document text
            for documentID in info["ids"]:
                document = fileContent.find_one({'cid': documentID})       # fetching document
                document["content"] = document["content"].replace('"',"")  # removing double qoutes
                document["content"] = document["content"].replace("'","")  # removing single qoutes
                document["content"] = re.sub(r'\w+:\/{2}[\d\w-]+(\.[\d\w-]+)*(?:(?:\/[^\s/]*))*'\
                    , '', document["content"])                             # removing http URLs
                document["content"] = document["content"].replace("\n","") # removing line breaks
                document["content"] = document["content"].replace("..","") # removing extra dots
                documents.append(document["content"].lower())              # coverting to lowercase
            logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - relInit: documents pre-processed")

            # Splitting the text to sentences
            tokens = []
            for document in documents:
                tokens = tokens + tokenizer.tokenize(document.encode('ascii','ignore'))
            logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - relInit: documents tokenized")

            # Performing SRL
            SPOs = [] # array to store Subject Predicate Objects
            count = 1 # progress tracker
            
            logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - relInit: SRL Starts")
            # Iterating each sentence for tagging them with SRL Labels
            for token in tokens: 
                if len(token) <= 1024:
                    logging.debug("TOKEN: " + token)
                    annotated_token = annotator.getAnnotations(token,dep_parse=True) # SRL Tagger
                    logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - relInit: token annotated")

                    # Converting the JSON Response from Annotator to Ontofy SPO Format i.e.:
                    # <SUBJECT>|---->|<ACTION>|---->|<OBJECT>
                    for srl in annotated_token['srl']:
                        tempstr = ""

                        if 'A0' in srl:                             # 'A0' refers to <SUBJECT>
                            tempstr = tempstr + srl['A0'] + ' |---->| '
                        elif 'A1' in srl:                           # 'A1' refers to <SUBJECT>
                            tempstr = tempstr + srl['A1'] + ' |---->| '

                        tempstr = tempstr + srl['V'] + ' |---->| '  # 'V' refers to <ACTION>

                        if 'A1' in srl:
                            tempstr = tempstr + srl['A1']
                        elif 'A2' in srl:                           # 'A2' refers to <OBJECT>
                            tempstr = tempstr + srl['A2']
                        SPOs.append(tempstr)

                # Updating the Progress
                currentProgress = progressDB.find_one({"p_id":info['p_id']})
                currentProgress["progress"] = str(count*100.0/len(tokens))
                progressDB.save(currentProgress)
                logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - relInit: current progress %s%",currentProgress)
                count = count + 1

            ############################################################################################################
            # Generating the result that needs to be pushed to the DB
            # Format: {
            #           "user_id":<Ontofy User ID>,
            #           "p_id":<Ontofy Project ID>,
            #           "task":"relation",
            #           "results":{
            #                       "extractedSPOs":{ 
            #                                        "NUMERIC_INDEXES": <SPOs>,...
            #                                        },
            #                       "selectedSPOs":{
            #                                           "NUMERIC_INDEXES":{}
            #                                       }
            #                     }
            #           }
            #
            ############################################################################################################
            logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - relInit: output generation starts")
            output='{"p_id":"'+info["p_id"]+'","user_id":"'+info["user_id"]\
            +'","task":"relation","results":{ "extractedSPOs":{'
            i = 1
            for SPO in SPOs:
                output = output + '"' + str(i) + '":"' + SPO.decode("ascii","ignore") + '",'
                i = i + 1
            if len(SPOs) == 0:
                output = output + '},"selectedSPOs": {}}}'
            else:
                output = output[:-1] + '},"selectedSPOs": {}}}'
            output = json.loads(output)
            logging.debug("relationship output as generated: {0}".format(output))
            # Finishing processing
            relationshipResults.insert_one(output) # write the new results to DB
            time.sleep(5) # halt the program

            progressDB.remove({"p_id":info['p_id']}) # delete the progress document
            logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - relInit: successfully closing the request")
            return jsonify({"status":"success","result":""}),201

        except Exception as e:
            logging.error(e)
            return jsonify({"status":"error","result":""}),500
###########################################End of Relationship Extraction  Web Service##################################




"""
root -> subject: csubj, nsubj
root -> Object : obj, obl, iobj
concatenations : advmod, amod, aux, compound, cop, det, expl, fixed, flat, goeswith, nmod, nummod, xcomp
synonyms       : appos, conj, list
"""

@app.route('/v3/relInit',methods=['POST'])
def relInitv3():
    info = request.json
    logging.info("request received for Relationship extraction: {0}".format(info))
    if not info:
        logging.error("- " + info["p_id"] + " - " + info["user_id"] + " - relInit: data not received in the body or as JSON")
        abort(400) # if data not received abort the call with HTTP error code 400
    else:
        # try:
        # Initializing the DB
        db = MongoClient([app.config['MONGODB_SERVER_URL']])
        relationshipResults = db.Ontology.tempjsons
        fileContent = db.Ontology.filecontents
        logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - relInit: DB initialized")

        # Intializing progress DB
        progressDB = db.Ontology.relProgress
        progress = {"progress":"1","p_id":info['p_id']}
        progressDB.insert_one(progress)
        logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - relInit: progress initialized")

        # Fetching the supplied documents and pre processing them
        documents = []
        for documentID in info["ids"]:
            document = fileContent.find_one({'cid': documentID})       # fetching document
            # document = clean_and_tokenize_document_into_sentence(document['content'])
            #document["content"] = document["content"].replace('"',"")  # removing double qoutes
            #document["content"] = document["content"].replace("'","")  # removing single qoutes
            #document["content"] = re.sub(r'\w+:\/{2}[\d\w-]+(\.[\d\w-]+)*(?:(?:\/[^\s/]*))*'\
            #    , '', document["content"])                             # removing http URLs
            #document["content"] = document["content"].replace("\n","") # removing line breaks
            #document["content"] = document["content"].replace("..","") # removing extra dots
            documents.append(document['content'])              # coverting to lowercase
        logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - relInit: documents pre-processed")

        # update progress after documents are collected
        progress = {"progress":"50", "p_id":info['p_id']}
        progressDB.update({"p_id":info['p_id']}, progress, upsert = True)
        logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - relInit: progress initialized")
        
        # extract relations from the document
        dependency_tree = requests.post(app.config['DEPENDENCY_PARSER_URL'], json = {"documents" : documents, "p_id" : info["p_id"], "user_id" : info["user_id"]}).json()
        #relation data into string for debug log
        rel_data = json.dumps(dependency_tree)
        logging.debug("- " + info["p_id"] + " - " + info["user_id"] + rel_data)
        ############################################################################################################
        # Generating the result that needs to be pushed to the DB
        # Format: {
        #           "user_id":<Ontofy User ID>,
        #           "p_id":<Ontofy Project ID>,
        #           "task":"relation",
        #           "results":{
        #                       "extractedSPOs":{ 
        #                                        "NUMERIC_INDEXES": <SPOs>,...
        #                                        },
        #                       "selectedSPOs":{
        #                                           "NUMERIC_INDEXES":{}
        #                                       }
        #                     }
        #           }
        #
        ############################################################################################################
        logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - relInit: output generation starts")

        dependency_tree = dict(map(lambda x : ( x[0].replace('.', ''), x[1] ), list(dependency_tree.items())))

        relationshipResults.insert_one({'p_id' : info['p_id'], 'user_id' : info['user_id'], 'task' : 'relation', 
                                        'results' : { 'extractedSPOs' : dependency_tree, 'selectedSPOs' : {} } })
        progressDB.remove({"p_id":info['p_id']}) # delete the progress document
        logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - relInit: successfully closing the request")
        return jsonify({"status":"success","result":""}),201

        """
        except Exception as e:
            logging.info("find error")
            logging.error(e)
            print(e)
            print(e.with_traceback())
            return jsonify({"status":"error","result":""}),500
        """

@app.route('/v4/relationships/external',methods=['POST'])
def external_relationships_v4():
  """
  input {
          "files" : [String]
        }
  """
  try:
    info = request.json
    result = {}
    logging.info("request received for Relationship extraction: {0}".format(info))
    tokenizer = PunktSentenceTokenizer()
    for file_content in info['files']:
      sentence_tokens = tokenizer.tokenize(file_content)
      for sentence in sentence_tokens:
        if sentence not in result:
          relations = relationship_triplets(sentence)
          result[sentence] = relations
    return jsonify({"status":"success","result":result}),201
  except Exception as e:
            logging.error(e)
            return jsonify({"status":"error","result":""}),500
'''
    VERSION : 4.0
    AUTHOR : shikhar.chaudhary@soprasteria.com
'''
@app.route('/v4/relationships',methods=['POST'])
def relationships_v4():
    info = request.json
    logging.info("request received for Relationship extraction: {0}".format(info))
    if not info:
        logging.error("- " + info["p_id"] + " - " + info["user_id"] + " - relInit: data not received in the body or as JSON")
        abort(400) # if data not received abort the call with HTTP error code 400
    else:
        try:
            # Initializing the DB
            db = MongoClient([app.config['MONGODB_SERVER_URL']])
            #store the extracted relationship temporarily
            relationshipResults = db.Ontology.tempjsons
            #ontofy file data is stored
            fileContent = db.Ontology.filecontents
            logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - relInit: DB initialized")

            # Intializing progress DB
            progressDB = db.Ontology.relProgress
            #set the progess to 1
            progress = {"progress":"1","p_id":info['p_id']}
            progressDB.insert_one(progress)
            logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - relInit: progress initialized")
            #store the final data of relationships
            result = {}
            # Fetching the supplied documents and pre processing them
            document_sentences = []
            total_documents = len(info["ids"])
            tokenizer = PunktSentenceTokenizer()
            #get all the sentences in all documents
            for documentID in info["ids"]:
                # fetching document from DB
                document = fileContent.find_one({'cid': documentID})
                #creating tokens from document
                tokens = tokenizer.tokenize(document['content'])
                document_sentences.extend(tokens)
            total_sentences = len(document_sentences)
            logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - total_sentences : " + str(total_sentences))

            #get relations per sentence
            for i in range(0, total_sentences):
                document_sentence = document_sentences[i]
                # Updating the progress
                currentProgress = progressDB.find_one({"p_id":info['p_id']}) # fetching the previous progress document
                progress = str(int(i*100/total_sentences)) # updating progress value
                currentProgress["progress"] = progress
                progressDB.save(currentProgress) # updating the progress document with new value
                logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - current : " + str(i))
                logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - progress : " + progress)
                #to avoid repetitive sentances
                if document_sentence not in result:
                    relations = relationship_triplets(document_sentence)
                    result[document_sentence] = relations
            
            #relation data into string for debug log
            rel_data = json.dumps(result)
            logging.debug("- " + info["p_id"] + " - " + info["user_id"] + rel_data)
            ############################################################################################################
            # Generating the result that needs to be pushed to the DB
            # Format: {
            #           "user_id":<Ontofy User ID>,
            #           "p_id":<Ontofy Project ID>,
            #           "task":"relation",
            #           "results":{
            #                       "extractedSPOs":{ 
            #                                        "NUMERIC_INDEXES": <SPOs>,...
            #                                        },
            #                       "selectedSPOs":{
            #                                           "NUMERIC_INDEXES":{}
            #                                       }
            #                     }
            #           }
            #
            ############################################################################################################
            logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - relInit: output generation starts")

            result = dict(map(lambda x : ( x[0].replace('.', ''), x[1] ), list(result.items())))

            relationshipResults.insert_one({'p_id' : info['p_id'], 'user_id' : info['user_id'], 'task' : 'relation', 
                                            'results' : { 'extractedSPOs' : result, 'selectedSPOs' : {} } })
            progressDB.remove({"p_id":info['p_id']}) # delete the progress document
            logging.info("- " + info["p_id"] + " - " + info["user_id"] + " - relInit: successfully closing the request")
            return jsonify({"status":"success","result":"data pushed into DB"}),201
        except Exception as e:
            logging.error(e)
            return jsonify({"status":"error","result":""}),500

def relationship_triplets(sentence):
    parsed_tree, root_index=merge_tree(sentence)
    #list of lables that make subject relationships with root
    #for the ones having head as pred
    are_subject = ["nsubj", "csubj"]

    #list of lables that make object relationships with root
    are_root_object = ["obl", "obj", "acomp", "xcomp"]#, "cop", "advcl" 
    #contain all relation
    relations = []
    #root word relations
    root_word = parsed_tree[root_index]["word"]
    #get the subject 
    #TODO : (optimize the logic) (each rule goes as a function)
    for i in range(0, len(parsed_tree)):
        label = str(parsed_tree[i]["label"])
        #get the main lable part if sub lable is also present
        if (label.rfind(':') >= 0):
            label = label[:label.rfind(':')]
        #Rule 1        
        rule_relations = rule_is_subject(parsed_tree, label, i)
        if len(rule_relations) > 0:
            relations.extend(rule_relations)
        #Rule 2
        relation = rule_no_object_tree(parsed_tree, root_index, label, i)
        if len(relation) > 0:
            relations.append(relation)
        #Rule 3
        relation = rule_modifier_relations(parsed_tree, label, i)
        if len(relation) > 0:
            relations.append(relation)
    return relations

        
'''
 TYPE : utility
 version : 4.0
 functionality :
  1. Rule for relationship extraction
  2. subject -> root/root of subtree -> object
'''
def rule_is_subject(parsed_tree, label, i):
    relations = []
    relation = []
    #for the ones having head as pred
    are_subject = ["nsubj", "csubj"]
    #list of lables that make object relationships with root
    are_root_object = ["obl", "obj", "acomp", "xcomp"]#, "cop", "advcl"
    if label in are_subject:
        subject_word=str(parsed_tree[i]["word"])

        # store all possible replacements
        sub_pronoun_replacers = []
        pronoun_replacers_for = ["nsubj", "csubj"]
        sub_pronoun_replacers = get_pronoun_replacers(parsed_tree, i, pronoun_replacers_for)

        possible_relations_lables = parsed_tree[parsed_tree[i]["head"]]["tail_lables"]
        possible_relations_indexes = parsed_tree[parsed_tree[i]["head"]]["tails"]
        for p_r_l_index in range(0,len(possible_relations_lables)):
            lable = possible_relations_lables[p_r_l_index]
            index = possible_relations_indexes[p_r_l_index]
            #store the relation 0->subject 1->pred 2->object
            relation = []
            #the current word
            word = str(parsed_tree[index]["word"])
            pred = str(parsed_tree[parsed_tree[index]["head"]]["word"])
            #if the object has case relation case is added to the connector
            if "case" in parsed_tree[index]["tail_lables"]:
                case_index = get_tail_index_by_label(parsed_tree, "case", index)
                pred = pred +" "+ parsed_tree[case_index]['word']
            #add the word if it is a keyword
            if lable in are_root_object:
                if parsed_tree[index]['head'] == parsed_tree[i]['head']:
                    relation = make_relation(subject_word, pred, word)
                    relations.append(relation)
                    for sub_word in sub_pronoun_replacers:
                        relation = make_relation(sub_word, pred, word)
                        relations.append(relation)
                    #handle the realations with conj
                    #index of conj
                    obj_tail_lables = parsed_tree[index]['tail_lables']
                    for index_o_t_l in range(0,len(obj_tail_lables)):
                        obj_tail_lable = obj_tail_lables[index_o_t_l]
                        if obj_tail_lable == 'conj':
                            word = str(parsed_tree[parsed_tree[index]['tails'][index_o_t_l]]['word'])
                            relation = make_relation(subject_word, pred, word)
                            relations.append(relation)
                            for sub_word in sub_pronoun_replacers:
                                relation = make_relation(sub_word, pred, word)
                                relations.append(relation)
    return relations

'''
 TYPE : utility
 version : 4.0
 functionality :
  1. Rule for relationship extraction
  2. subject -> root/root of subtree -> object
'''
#relations of nmod terms
#current_index : index of the current element
#label : current word label
def rule_modifier_relations(parsed_tree, label, current_index):
    relation = []
    subject_word = None  
    pred = None
    obj = None
    #having connection with both pred and object
    are_modifiers = ["nmod"]
    if label in are_modifiers:
        
        #the modifier is the object
        obj=str(parsed_tree[current_index]["word"])
        # get predicate (for nmod modifier is case)
        if len(parsed_tree[current_index]["tails"]) > 0:
            
            #get the case predicate
            if "case" in parsed_tree[current_index]["tail_lables"]:
                case_index = get_tail_index_by_label(parsed_tree, "case", current_index)
                pred = str(parsed_tree[case_index]['word'])
            #get the subject (we hop till we reach a noun or root word)
            #hop to parent
            parent_index = hop_up(parsed_tree, current_index)
            #get parent lable
            parent_label = parsed_tree[parent_index]['label']
            #holds the subject word
            subject_word = ""
            while subject_word == "":
                #type 1
                if parent_label in ["obl", "obj", "root"]:                    
                    subject_word =  str(parsed_tree[parent_index]["word"])
                #type 2
                elif parent_label in ["nsubj", "csubj"]:
                    parent_head_index = parsed_tree[parent_index]["head"]
                    tails_of_subject_head = parsed_tree[parent_head_index]["tail_lables"]
                    condition = any(elem in tails_of_subject_head for elem in ["obj","obl"])
                    if condition:
                        # get the realated terms (relation is nmod -> nsubj + (optional root) -> obj/obl )
                        for obj_label in ["obj","obl"]:
                            if obj_label in tails_of_subject_head:
                                nsubj_index = get_tail_index_by_label(parsed_tree, obj_label, parent_head_index)
                                subject_word = obj
                                obj=str(parsed_tree[nsubj_index]["word"])
                                pred = str(parsed_tree[parent_index]["word"])                       
                    else :
                        subject_word =  str(parsed_tree[parent_index]["word"])
                else:
                    parent_index = hop_up(parsed_tree, parent_index)
                    parent_label = parsed_tree[parent_index]['label']
            #check to handle (eg. It quantitates greater than or equal to 0.004 IU/mL.)
            if (subject_word != None and pred != None and obj != None):
                relation = make_relation(subject_word, pred, obj)
    return relation

#Some verbs can be used with or without an object,
#but the relationship between the verb and the subject
#is different in each case. When these verbs have an object,
#the subject does the action. When they have no object,
#the action or event happens to the subject.
#root_index : index of root word
#current_index : index of the current element
#label : current word label
def rule_no_object_tree(parsed_tree, root_index, label, current_index):
    relation = []
    #when tree has no object(eg. the last word of an identified noun phrase is the head noun.)
    condition = not any(elem in parsed_tree[root_index]["tail_lables"] for elem in ["obj","obl"])
    if condition:
        #type 1
        #nsubj head -> nsubj -> nmod
        if label == "nsubj": 
            #head of nsubj is the subject
            subject_word = str(parsed_tree[parsed_tree[current_index]["head"]]['word'])
            #pred is the nsubj
            pred = str(parsed_tree[current_index]['word'])
            #strict for nmod (can make a function of below lines with nmod as parameter)
            if "nmod" in parsed_tree[current_index]["tail_lables"]:
                nmod_index = get_tail_index_by_label(parsed_tree, "nmod", current_index)
                obj = str(parsed_tree[nmod_index]['word'])
                relation = make_relation(subject_word, pred, obj)
    return relation
'''
 TYPE : utility
 version : 4.0
 functionality :
  1. merge the pharses in the tree, hold the original word too.
  2. handle cases for conjunctions
'''
def merge_tree(sentence):
    lables_to_merge = ["compound","amod", "advmod", "appos","flat"]
    annotate_sentence_request = {"sentence" : sentence}
    #later repace with d_tree container
    annotate_sentence_response = requests.post("http://slnxdigtnpoc01.noid.in.sopra:4001/annotate_sentence", json = annotate_sentence_request).json()
    parsed_tree = annotate_sentence_response["tree"]
    #store the indexs of the compound word head (Will have the phrases after the merging loop completes)
    phrases_indxes = []
    #merge compound words and modifier(amod) (Try doing with tree dataStructure later on)
    #traverse the tree in buttom up manner
    for index in range(len(parsed_tree) - 1, -1, -1):
        label = str(parsed_tree[index]["label"])
        #add tail data to head
        head_index = parsed_tree[index]["head"]
        parsed_tree[head_index]["tail_lables"].append(label)
        parsed_tree[head_index]["tails"].append(index)
        
        #get the index of root word
        if label == "root":
            root_word_index = index
        # to handle case : e.g --> a and b c (explain : both a and b are type of c)
        if label == "conj":
            head_word_index = parsed_tree[index]["head"]
            head_word_label = parsed_tree[head_word_index]["label"]
            if head_word_label == "compound":
                compound_word_head_index = parsed_tree[head_word_index]["head"]
                compound_word_head = parsed_tree[compound_word_head_index]["original_word"]
                if parsed_tree[index]["start"] > parsed_tree[compound_word_head_index]["start"]:
                    parsed_tree[index]['word'] = compound_word_head + " " + parsed_tree[index]['word']
                else: 
                    parsed_tree[index]['word'] = parsed_tree[index]['word'] + " " + compound_word_head
        
        # merge the word with it's head if lables are compound, amod, nummod, advmod
        # add more lables in lables_to_merge list if required
        if label in lables_to_merge:
            compound_word = parsed_tree[index]["word"]
            head_word_index = parsed_tree[index]["head"] 
            if head_word_index not in phrases_indxes:
                phrases_indxes.append(head_word_index)
            # add the word after it's head  
            if parsed_tree[index]["start"] > parsed_tree[head_word_index]["start"]:
                #get the connector of the word
                break_level = str(parsed_tree[index]["break_level"])
                connector = get_connector(break_level)

                parsed_tree[head_word_index]["word"] = parsed_tree[head_word_index]["word"] + connector + compound_word
            # add the word before it's head 
            else:
                #get the connector of the head
                break_level = str(parsed_tree[head_word_index]["break_level"])
                connector = get_connector(break_level)

                parsed_tree[head_word_index]["word"] = compound_word + connector + parsed_tree[head_word_index]["word"]
                #so that the comming words join as per the break level of the word coming prior in sequence
                parsed_tree[head_word_index]["break_level"] = parsed_tree[index]["break_level"]
            for i in range(0, len(parsed_tree)):
                if parsed_tree[i]["head"] == index:
                    parsed_tree[i]["head"] = parsed_tree[index]["head"]
    return parsed_tree, root_word_index
'''
 TYPE : utility
 Version : 4.0
 functionality : check if the current word is a pronoun.
'''
def check_word_for_pronoun(parsed_tree, index):
    pronoun_index = str(parsed_tree[index]['tag']).lower().find("name: \"prontype\"")
    if pronoun_index > -1:
        return True
    else: 
        return False
'''
 TYPE : utility
 Version : 4.0
 functionality : to find possible noun replacers for a pronoun
'''
def get_pronoun_replacers(parsed_tree, index, pronoun_replacers_for):
    
    #check for pronoun
    is_pronoun = check_word_for_pronoun(parsed_tree, index)
    #store possible replacements
    pronoun_replacers = []
    if is_pronoun :
        #jump to head index
        head = hop_up(parsed_tree, index)
        #loop to the top, break at hop for root head(-1)
        while True:
            #all the tails
            tail_lables = parsed_tree[head]['tail_lables']
            #check is any tail forms a noun subject relation
            has_subject = any(elem in tail_lables for elem in pronoun_replacers_for)
            if has_subject :
                #get lables of noun subject
                sub_labels = [elem  for elem in tail_lables if elem in pronoun_replacers_for]
                for label in sub_labels:
                    #find the indices of noun subjects
                    sub_index = get_tail_index_by_label(parsed_tree, label, head)
                    #do not add if the word is a pronoun
                    is_pronoun = check_word_for_pronoun(parsed_tree, sub_index)
                    if not is_pronoun:
                        pronoun_replacers.append(str(parsed_tree[sub_index]["word"]))
            #next level
            head = hop_up(parsed_tree, head)
            #break on reaching root
            if head == -1:
                break
    return pronoun_replacers
'''
 TYPE : utility
 version : 4.0
 functionality : Jump to head word
'''
def hop_up(parsed_tree, current_index):
    return parsed_tree[current_index]['head']
'''
 TYPE : utility
 version : 4.0
 functionality : return the relationship in specified format
'''
def make_relation(subject, predicate, obj):
    relation =  subject+ "-->"  +  predicate + "-->" + obj
    #TODO use the below format.
    '''
    relation = []
    relation.append(subject)
    relation.append(predicate)
    relation.append(obj)
    '''
    return relation
'''
 TYPE : utility
 version : 4.0
 functionality : return the tail with specified relation

#label : the tail label to find
#current_index : index of the current element
'''
def get_tail_index_by_label(parsed_tree, label, current_index):
    for index_t_l in range(0,len(parsed_tree[current_index]["tail_lables"])):
        if parsed_tree[current_index]["tail_lables"][index_t_l] == label:
            return parsed_tree[current_index]["tails"][index_t_l]

'''
 TYPE : utility
 version : 4.0
 functionality : return the connector for words to be merged in the d_tree
'''
def get_connector(break_level):
    connector = " "
    if break_level == "0":
        connector = ""
        
    return connector

""" 
    Utility method to extract relations from the annotations generated by dependency parsing
"""
def extract_relations_from_annotations(sentence, annotated_sentence):
    logging.debug("extract relations from the annotated sentence for: {0}".format(annotated_sentence))
    labels_to_ignore = ["punct", "case", "det", "cc", "mark", "auxpass", "cop", "discourse", 
                        "mark", "mwe", "num", "pobj", "possessive", "preconj", "prep", "ref", "preconj", "nmod:poss"]
    labels_to_join = ["conj", "compound", "advmod", "aux", "head", "amod"]

    root = None
    roles = {}
    tokens = annotated_sentence.token
    tokenized_sentence = [token.word for token in tokens]

    ## tokenized_sentence = nltk.word_tokenize(sentence, preserve_line= True)
    ## using spacy:
    #if sys.version[0] == '2':
    #    sentence = unicode(sentence)

    #spacy_parsed_doc = spacy_model(sentence)
    #tokenized_sentence = [token.text for token in spacy_parsed_doc if re.search(r'\s', token.text) is None]
    

    for token in tokens:
        logging.debug("look for '{0}' in the sentence: '{1}'".format(token, sentence))
        if token.label not in labels_to_ignore:
            head = token.head
            if head > -1:
                head_start = sentence.index(tokenized_sentence[head])
                if head not in roles:
                    roles[head] = {}
                    roles[head]['head'] = []
                    roles[head]['head'].append((tokenized_sentence[head], head_start))
    
                if token.start > head_start:
                    if 'after' not in roles[head]:
                            roles[head]['after'] = []
                    roles[head]['after'].append((token.word, token.start, token.label))
                else:
                    if 'before' not in roles[head]:
                            roles[head]['before'] = []
                    roles[head]['before'].append((token.word, token.start, token.label))
            else:
                root = token
    
        
    heads_to_replace = {}
    
    for head in sorted(roles.keys(), reverse = True):
        #roles[head]['head'][0] = roles[head]['head'][0]

        # consolidate the roles
        if 'before' in roles[head]:
            for prefix in roles[head]['before']:
                if prefix[2] in labels_to_join:
                    roles[head]['head'][0] = (prefix[0] + " " + roles[head]['head'][0][0], prefix[1], roles[head]['head'][0][0])
                    # roles[head]['head'][0][1] = 
                    roles[head]['before'].remove(prefix)

                    if len(roles[head]['before']) == 0:
                        roles[head].pop('before')

        if 'after' in roles[head]:
            for suffix in roles[head]['after']:
                if suffix[2] in labels_to_join:
                    roles[head]['head'][0] = (roles[head]['head'][0][0] + " " + suffix[0], suffix[1], roles[head]['head'][0][0])
                    
                    #roles[head]['head'][0][1] = 
                    roles[head]['after'].remove(suffix)

                    if len(roles[head]['after']) == 0:
                        roles[head].pop('after')
    
    for head in sorted(roles.keys(), reverse = True):
        roles[head]['head'][0] = roles[head]['head'][0]

        if 'before' not in roles[head] and 'after' not in roles[head] and len(roles[head]['head'][0]) == 3:
            heads_to_replace[roles[head]['head'][0][2]] = roles[head]['head'][0][0]
            roles.pop(head)

        elif 'before' not in roles[head] and 'after' in roles[head]:
            if len(roles[head]['head'][0]) == 3:
                heads_to_replace[roles[head]['head'][0][2]] = roles[head]['head'][0][0] + " " + " ".join(list(map(lambda x : x[0], 
                                                                            sorted(roles[head]['after'], key = lambda x : x[1]))))
                roles[head].pop('after')
            else:
                heads_to_replace[roles[head]['head'][0][0]] = roles[head]['head'][0][0] + " " + " ".join(list(map(lambda x : x[0], 
                                                                            sorted(roles[head]['after'], key = lambda x : x[1]))))
                roles[head].pop('after')
                
        elif 'after' not in roles[head] and 'before' in roles[head]:
            if len(roles[head]['head'][0]) == 3:
                heads_to_replace[roles[head]['head'][0][2]] = " ".join(list(map(lambda x : x[0], sorted(roles[head]['before'], 
                                                        key = lambda x : x[1])))) + " " + roles[head]['head'][0][0]
                roles[head].pop('before')
            else:
                heads_to_replace[roles[head]['head'][0][0]] = " ".join(list(map(lambda x : x[0], sorted(roles[head]['before'], 
                                                                        key = lambda x : x[1])))) + " " + roles[head]['head'][0][0]
                roles[head].pop('before')

    # consolidate
    relations = {}
    for head in sorted(roles.keys(), reverse = True):
        before = None
        after = None
        head_str = None

        # consolidate before
        if 'before' in roles[head]:
            before = " ".join(list(map(lambda x : x[0] if x[0] not in heads_to_replace else heads_to_replace[x[0]],
                                       sorted(roles[head]['before'], key = lambda x : x[1]))))

        # consolidate after
        if 'after' in roles[head]:
            after = " ".join(list(map(lambda x : x[0] if x[0] not in heads_to_replace else heads_to_replace[x[0]], 
                                      sorted(roles[head]['after'], key = lambda x : x[1]))))


        # consolidate head
        head_str = roles[head]['head'][0][0] if roles[head]['head'][0][0] not in heads_to_replace \
        else heads_to_replace[roles[head]['head'][0][0]]

        if before is not None and after is not None:
            relations[head] = before + "-->" + head_str + "-->" + after
            
    return list(relations.values())

"""
    Utility method to clean the document of punctuations and tokenize to sentences
"""
def clean_and_tokenize_document_into_sentence(document):
    document = document.encode("ascii","ignore").replace('"',"").replace("'","").replace("\n","").replace("..","").lower()
    # document = re.sub(r'\w+:\/{2}[\d\w-]+(\.[\d\w-]+)*(?:(?:\/[^\s/]*))*', '', document)
    logging.debug("to be removed doc transformed as: {0}".format(document))
    return nltk.sent_tokenize(document)

"""
    Service to accept documents and output as the relations
    to be moved to Tensor flow API
"""
@app.route("/extract_relations", methods = ['POST'])
def extract_relationships_using_dependency_parser():
    input = request.json
    logging.debug("Dependency Parser: request received for relationship extraction : {0}".format(input))
    
    if 'documents' in input.keys():
        documents = input['documents']
    logging.debug("documents received for relationship extraction : {0}".format(documents))
    sentences = list(chain(*map(lambda x : nltk.sent_tokenize(x), documents)))
    #annotated_sentences = []
    relations = {}
    logging.debug("tokenized document: {0}".format(sentences))

    chars_to_delete = str(app.config['DEPENEDENCY_PARSER_CHARS_TO_DELETE'])
    chars_to_replace = str(app.config['DEPENEDENCY_PARSER_CHARS_TO_REPLACE'])
    logging.debug("process sentences")
    #translator_for_replacement = string.maketrans(str(chars_to_replace), ' ' * len(chars_to_replace))
    
    for sentence in sentences:
        sentence = str(sentence.encode('ascii', 'ignore'))
        
        #sentence = sentence.translate(translator_for_replacement)
        logging.debug("remove unwanted characters from sentence: {0}".format(sentence))
        logging.debug("dtype of sentence: {0}".format(type(sentence)))  
        sentence = sentence.translate(None, chars_to_delete)

        logging.debug("fetching relations for the sentence: {0}".format(sentence))
        if sentence not in relations:
            annotated_sentence = annotate_text(sentence)
            #annotated_sentences.append(annotated_sentence)
            relations[sentence] = extract_relations_from_annotations(sentence, annotated_sentence)
    
    return jsonify(relations)

"""
    Service to accept a sentence and output the parsed tree
    -Only caters to a single sentence

@app.route("/annotate_sentence", methods = ['POST'])
def annotate_sentence():
    logging.info("inside annotate_sentence")
    # get the json body from the request
    input = request.json
    # extract the sentence to be parsed
    sentence = input['sentence']
    sentence = str(sentence.encode('ascii', 'ignore'))
    logging.debug("sentence received for parsing : {0}".format(sentence))
    #TODO : how to handle the error
    logging.info("calling")
    annotated_sentence = annotate_text(sentence)
    parsed_tree = [{"word" : annotated_sentence.token[index].word, "start" : annotated_sentence.token[index].start, "end" : annotated_sentence.token[index].end, "head" : annotated_sentence.token[index].head, "tag" : annotated_sentence.token[index].tag, "category" : annotated_sentence.token[index].category, "label" : annotated_sentence.token[index].label, "break_level" : annotated_sentence.token[index].break_level,} for index in range(0, len(annotated_sentence.token))]
    result = {"tree" : parsed_tree}
    return jsonify(result)
"""
@app.route("/annotate_sentence", methods = ['POST'])
def annotate_sentence():
    logging.info("inside annotate_sentence")
    # get the json body from the request
    input = request.json
    # extract the sentence to be parsed
    sentence = input['sentence']
    sentence = str(sentence.encode('ascii', 'ignore'))
    logging.debug("sentence received for parsing : {0}".format(sentence))
    #TODO : how to handle the error
    logging.info("calling")
    annotated_sentence = annotate_text(sentence)
    parsed_tree = [{"word" : annotated_sentence.token[index].word, "tails": [], "tail_lables": [], "original_word": annotated_sentence.token[index].word, "start" : annotated_sentence.token[index].start, "end" : annotated_sentence.token[index].end, "head" : annotated_sentence.token[index].head, "tag" : annotated_sentence.token[index].tag, "category" : annotated_sentence.token[index].category, "label" : annotated_sentence.token[index].label, "break_level" : annotated_sentence.token[index].break_level,} for index in range(0, len(annotated_sentence.token))]
    result = {"tree" : parsed_tree}
    return jsonify(result)

"""
    Utility method to return a dependency parsed relation in the format of Subject --> Predicate--> Object
"""
# deprecated
def find_spo_relations_in_order(sentence, annotated_sentence):
    labels_to_ignore = ["punct", "case", "det", "cc", "mark", "auxpass", "cop", "discourse", 
                        "mark", "mwe", "num", "pobj", "possessive", "preconj", "prep", "ref", "preconj", "nmod:poss"]
    labels_to_join = ["conj", "compound", "advmod", "aux"]
    
    tokens = annotated_sentence.token
    filtered_annotations = list(filter(lambda x : x.label not in labels_to_ignore, tokens))
    
    heads = list(set(map(lambda x : x.head, filtered_annotations)))
    tokenized_sentence = nltk.word_tokenize(sentence, preserve_line = True)
    print("\n heads : {0} fetched from filtered annotations : {1}".format(heads, filtered_annotations))
    heads = list(map(lambda x : tokenized_sentence[x] if x > -1 else 'root', heads))
    root = None

    roles = {}
    for token in tokens:
        if token.label not in labels_to_ignore:
            
            if token.head not in roles:
                roles[token.head] = []
                
            if token.label == 'root':
                root = token.word

            roles[token.head].append((token.word, token.label, token.start))
    
    # remvoe root from heads
    roles.pop(-1)
    
    #print("\nroles: {0}".format(roles))
    
    relations = []
    for head, tmp_roles in roles.items():
        relation = ""
        tmp_roles.append((tokenized_sentence[head], 'head', sentence.index(tokenized_sentence[head])))
        
        tmp_roles = sorted(tmp_roles, key= lambda x : x[2])
        #print("\nbuild relation in : {0}".format(tmp_roles))
        
        if len(tmp_roles) > 2:
            for role in tmp_roles:
                if role != tmp_roles[-1]:
                    if role[1] in labels_to_join:
                        if relation.endswith(" "):
                                relation = relation + role[0] + " "
                        else:
                            relation = relation + " " + role[0] + " "
                    else:
                        relation = relation + role[0] + "-->"
                else:
                    relation = relation + role[0]
            print("\n built relation: {0} ----- adding in : {1}".format(relation, relations))
            relations.append(relation)
    
    if root not in heads:
        heads[heads.index('root')] = root
    else:
        heads.remove('root')
    
    return (relations, heads)


"""
    Utility method to extract relation interpretation from the dependencies parsed by Dependency Parsing 
    To be moved to tensor flow service
"""
# deprecated
def extract_relations_from_annotations_old(sentence, annotated_sentence):
    labels_to_ignore = ["punct", "case", "det", "cc", "mark", "auxpass", "cop", "discourse", 
                        "mark", "mwe", "num", "pobj", "possessive", "preconj", "prep", "ref", "preconj"]
    labels_to_join = ["conj", "compound", "advmod", "aux"]
    
    tokens = annotated_sentence.token
    filtered_annotations = list(filter(lambda x : x.label not in labels_to_ignore, tokens))
    
    heads = list(set(map(lambda x : x.head, filtered_annotations)))

    tokenized_sentence = nltk.word_tokenize(sentence)
    
    heads = list(map(lambda x : tokenized_sentence[x] if x > -1 else 'root', heads))
    root = None

    roles = {}
    for token in tokens:
        if token.label not in labels_to_ignore:
            if token.head not in roles:
                roles[token.head] = []
            if token.label == 'root':
                root = token.word

            roles[token.head].append((token.word, token.label, token.start))
    
    #print("roles", roles)
    roles = sorted(list(chain(*roles.values())), key= lambda x : x[2])
    #print("sorted roles", roles)
    relation = ""
    for role in roles:
        if roles[-1] != role:
            if role[1] in labels_to_join:
                if relation.endswith(" "):
                        relation = relation + role[0] + " "
                else:
                    relation = relation + " " + role[0] + " "
            else:
                relation = relation + role[0] + "-->"
        else:
            relation = relation + role[0]

    if root not in heads:
        heads[heads.index('root')] = root
    else:
        heads.remove('root')

    return {sentence : (relation, heads)}


"""
    This method will extract relationships within sentences of the uploaded documents
    Output will be a set of sentences splitted into its dependency tree provided by Tensorflow: SyntaxNet: Dependency Parser
"""
# deprecated
def extract_relations_old():
    input = request.json
    logging.debug("fetching relationships from dependency parser")
    if input is not None:
        documents = input['documents']
        project_id = input["p_id"]
        user_id = input["user_id"]
        logging.debug("request data : documents: {0}, project : {1}".format(documents, project_id))

    db = MongoClient([app.config['MONGODB_SERVER_URL']]).Ontology
    progressDB = db.get_collection(app.config['MONGODB_PROGRESS_COLLECTION'])

    # Splitting the text to sentences
    sentences = []
    tokenizer = PunktSentenceTokenizer()
    for document in documents:
        sentences.extend(clean_and_tokenize_document_into_sentence(document))
    logging.info("- " + project_id + " - " + user_id + " - relInit: documents tokenized {0}".format(sentences))

    count = 1
    SPOs = {}
    for token in sentences:
        #annotated_text = os.system('/opt/tensorflow/syntaxnet/bazel-bin/dragnn/tools/oss_notebook_launcher run dependency_parse.py "' + token + '"')
        annotated_text = annotate_text(token)
        logging.debug(annotated_text)
        action = ""
        action_index = -1
        action_phrases = []

        subjects = []
        subjects_index = []
        subjects_phrases = []

        objects = []
        objects_index = []
        objects_phrases = []
        
        SPOs[token] = []

        for i in range(0,len(annotated_text.token)):
            if annotated_text.token[i].label == "root":
                action = annotated_text.token[i].word
                action_index = i
                break
                        
        for i in range(0,len(annotated_text.token)):
            if annotated_text.token[i].head == action_index and (annotated_text.token[i].label.split(":")[0] == "csubj" or annotated_text.token[i].label.split(":")[0] == "nsubj"):
                subjects.append(annotated_text.token[i].word)
                subjects_index.append(i)
                for j in range(0,len(annotated_text.token)):
                    if annotated_text.token[j].head == i and (annotated_text.token[j].label.split(":")[0] == "appos" or annotated_text.token[j].label.split(":")[0] == "conj" or 
                                                              annotated_text.token[j].label.split(":")[0] == "list"):
                        subjects.append(annotated_text.token[j].word)
                        subjects_index.append(j)
                            
                        
        for i in range(0,len(annotated_text.token)):
            if annotated_text.token[i].head == action_index and (annotated_text.token[i].label.split(":")[0] == "obj" or annotated_text.token[i].label.split(":")[0] == "obl" or 
                            annotated_text.token[i].label.split(":")[0] == "iobj" or annotated_text.token[i].label.split(":")[0] == "xcomp" or 
                            annotated_text.token[i].label.split(":")[0] == "conj"):
                objects.append(annotated_text.token[i].word)
                objects_index.append(i)
                for j in range(0,len(annotated_text.token)):
                    if annotated_text.token[j].head == i and (annotated_text.token[j].label.split(":")[0] == "appos" or annotated_text.token[j].label.split(":")[0] == "conj" or 
                                                              annotated_text.token[j].label.split(":")[0] == "list"):
                        objects.append(annotated_text.token[j].word)
                        objects_index.append(j)

        for i in range(0,len(annotated_text.token)):
            if annotated_text.token[i].head == action_index and (annotated_text.token[i].label.split(":")[0] == "advmod" or annotated_text.token[i].label.split(":")[0] == "amod" or 
                                                                 annotated_text.token[i].label.split(":")[0] == "aux" or annotated_text.token[i].label.split(":")[0] == "compound" or 
                                                                 annotated_text.token[i].label.split(":")[0] == "cop" or annotated_text.token[i].label.split(":")[0] == "det" or 
                                                                 annotated_text.token[i].label.split(":")[0] == "expl" or annotated_text.token[i].label.split(":")[0] == "fixed" or 
                                                                 annotated_text.token[i].label.split(":")[0] == "flat" or annotated_text.token[i].label.split(":")[0] == "goeswith" or 
                                                                 annotated_text.token[i].label.split(":")[0] == "nmod" or annotated_text.token[i].label.split(":")[0] == "nummod" or 
                                                                 annotated_text.token[i].label.split(":")[0] == "xcomp"):
                action = action + "_" + annotated_text.token[i].word
        action_phrases.append(action)
        for j in range(0,len(annotated_text.token)):
                    if annotated_text.token[j].head == action_index and (annotated_text.token[j].label.split(":")[0] == "appos" or annotated_text.token[j].label.split(":")[0] == "conj" or 
                                                                         annotated_text.token[j].label.split(":")[0] == "list"):
                        subjects.append(annotated_text.token[j].word)
                        subjects_index.append(j)

        for j in range(0,len(subjects)):
            temp = subjects[j]
            for i in range(0,len(annotated_text.token)):
                if annotated_text.token[i].head == subjects_index[j] and (annotated_text.token[i].label.split(":")[0] == "advmod" or annotated_text.token[i].label.split(":")[0] == "amod" or 
                                                                          annotated_text.token[i].label.split(":")[0] == "aux" or annotated_text.token[i].label.split(":")[0] == "compound" or 
                                                                          annotated_text.token[i].label.split(":")[0] == "cop" or annotated_text.token[i].label.split(":")[0] == "det" or 
                                                                          annotated_text.token[i].label.split(":")[0] == "expl" or annotated_text.token[i].label.split(":")[0] == "fixed" or 
                                                                          annotated_text.token[i].label.split(":")[0] == "flat" or annotated_text.token[i].label.split(":")[0] == "goeswith" or 
                                                                          annotated_text.token[i].label.split(":")[0] == "nmod" or annotated_text.token[i].label.split(":")[0] == "nummod" or 
                                                                          annotated_text.token[i].label.split(":")[0] == "xcomp"):
                    temp = annotated_text.token[i].word + " " + temp
            subjects_phrases.append(temp)
                            
        for j in range(0,len(objects)):
            temp = objects[j]
            for i in range(0,len(annotated_text.token)):
                if annotated_text.token[i].head == objects_index[j] and (annotated_text.token[i].label.split(":")[0] == "advmod" or annotated_text.token[i].label.split(":")[0] == "amod" or 
                                                                         annotated_text.token[i].label.split(":")[0] == "aux" or annotated_text.token[i].label.split(":")[0] == "compound" or 
                                                                         annotated_text.token[i].label.split(":")[0] == "cop" or annotated_text.token[i].label.split(":")[0] == "det" or 
                                                                         annotated_text.token[i].label.split(":")[0] == "expl" or annotated_text.token[i].label.split(":")[0] == "fixed" or 
                                                                         annotated_text.token[i].label.split(":")[0] == "flat" or annotated_text.token[i].label.split(":")[0] == "goeswith" or 
                                                                         annotated_text.token[i].label.split(":")[0] == "nmod" or annotated_text.token[i].label.split(":")[0] == "nummod" or 
                                                                         annotated_text.token[i].label.split(":")[0] == "xcomp"):
                    temp = annotated_text.token[i].word + " " + temp
            objects_phrases.append(temp)

        if len(action_phrases) > 0:
            if len(subjects_phrases) > 0 and len(objects_phrases) > 0:
                for subj in subjects_phrases:
                    for act in action_phrases:
                        for obj in objects_phrases:
                            SPOs[token].append(subj + "|---->| " + act + " |---->| " + obj)
                            logging.debug("add relation : {0} |---->| {1} |---->| {2}".format(subj, act, obj))
            elif len(subjects_phrases) == 0 and len(objects_phrases) > 0:
                for act in action_phrases:
                    for obj in objects_phrases: 
                        SPOs[token].append("|---->| " + act + " |---->| " + obj)
                        logging.debug("add relation : |---->| {0} |---->| {1}".format(act, obj))
            if len(subjects_phrases) > 0 and len(objects_phrases) == 0:
                for subj in subjects_phrases:
                    for act in action_phrases:
                        SPOs[token].append(subj + "|---->| " + act + " |---->| ")
                        logging.debug("add relation : |---->| {0} |---->| ".format(act))
                                
        currentProgress = progressDB.find_one({"p_id" : project_id})
        if currentProgress is not None:
            currentProgress["progress"] = str(count*100.0/len(sentences))
            progressDB.save(currentProgress)
            logging.info("- {0} - {1} - relInit: current progress {2}".format(user_id, project_id, currentProgress))
        else:
            logging.debug("project {0} not found".format(project_id))
        count = count + 1
    logging.debug("output refined as: {0}".format(SPOs))
    return jsonify({'SPOs' : SPOs})

# Initializing  the flask application with port as 4892 and open to any incoming connection(0.0.0.0)
if __name__ == '__main__':
    app.run(host="0.0.0.0",port=4892,threaded=True,use_reloader=False)


########################################### END OF PROGRAM #############################################################
