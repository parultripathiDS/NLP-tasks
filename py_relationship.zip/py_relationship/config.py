########################################### START OF PROGRAM ###########################################################
'''
@author: <sauveer.goel@soprasteria.com>
'''
########################################################################################################################
# Implementation: Relationship Microservice Configration File [Ontofy.kit]
# Description:    This file enlists the various configurable parameters for the Relationship Microservice [Ontofy.kit]
########################################################################################################################


###########################################Start of Import Statements###################################################
import logging # to import log levels
###########################################End of Import Statements#####################################################


###########################################Start of Config Class########################################################
class Config(object):
    # specifying filename to store logs
    LOG_FILENAME =                     "logs/RelationshipMicroservice.log" 
    # defining custom log format
    LOG_FORMAT =                       "%(asctime)s:%(msecs)03d %(levelname)s %(filename)s:%(lineno)d %(message)s"
    # defining the date format for logger
    LOG_DATE_FORMAT =                  "%Y-%m-%d %H:%M:%S"
    # defining log levels
    LOG_LEVEL =                        logging.INFO
    # defining MongoDB server URL
    MONGODB_SERVER_URL =               "ontofy_mongodb_services:27017"
    # the time for the program to halt suchthat web service can catch 100% progress
    HAULT_TIME =                       5
    # Wikipedia R1 Request URL
    R1_REQUEST_URL =                   "https://www.wikidata.org/w/api.php?action=wbsearchentities&search="
    # Wikipedia R2 Request URL
    R2_REQUEST_URL =                   "https://www.wikidata.org/w/api.php?action=wbgetclaims&entity="
    # Wikipedia R3 Request URL
    R3_REQUEST_URL =                   "https://www.wikidata.org/w/api.php?action=wbgetentities&ids="
    # URL to access the property list from an OWL for a corresponing Ontofy Project ID
    OWL_RELATIONSHIP_CONSUMPTION_URL = 'http://slnxdigtnpoc01.noid.in.sopra:8083/OntologyAPI/extract/property?'
    # URL to extract types for a set of phrases
    CONCEPTNET_TYPES_URL = 'http://slnxdigtnpoc01.noid.in.sopra:4010/v1/types'
    DEPENDENCY_PARSER_URL = "http://slnxdigtnpoc01.noid.in.sopra:4001/extract_relations"
    MONGODB_PROGRESS_COLLECTION = 'relProgress'
    DEPENEDENCY_PARSER_CHARS_TO_DELETE = '-'
    DEPENEDENCY_PARSER_CHARS_TO_REPLACE = '\/'

#############################################End of Config Class########################################################
