#!/usr/bin/env python
# coding: utf-8
import pandas as pd
import pickle
import numpy as np
import os
import requests
from nltk.corpus import stopwords
from sklearn.feature_extraction.text import TfidfVectorizer
import re
from bs4 import BeautifulSoup
from gensim.models import FastText

def _replace(string, substitutions):
    substrings = sorted(substitutions, key=len, reverse=True)
    regex = re.compile('|'.join(map(re.escape, substrings)))
    return regex.sub(lambda match: substitutions[match.group(0)], string)

def get_documents_data():
    doc_path = os.getcwd() + '/documents'
    files = os.listdir(doc_path)
    output_data = []
    chunks = []
    for document_name in files:
        extension = os.path.splitext(document_name)
        doc_type = extension[1]
        tika_url = "https://ontologydcsallformat.azurewebsites.net/DocumentConversion/v1/json"
        if doc_type in ['.docx', '.doc']:
            filename = doc_path + '/' + document_name
            print(filename)
            with open(filename, 'rb') as file:
                files = {'file': file}
                json_data = requests.post(tika_url, files=files, proxies={'http': 'http://10.135.0.29:8080'}).json()
                html_file = json_data['htmlFileTag']
                soup = BeautifulSoup(html_file, 'html.parser')
                heading_tags = ['h1', 'h2', 'h3', 'h4']
                all_tags = soup.find_all(['h1', 'h2', 'h3', 'h4', 'p'])
                chunk = []
                chunk.append(document_name)
                para = ""
                for t in range(0, len(all_tags)):
                    tag = all_tags[t]
                    if tag.name in heading_tags:
                        chunk.append(tag.text.strip())
                    else:
                        para = para + tag.text.strip()
                        if t + 1 < len(all_tags) and all_tags[t + 1].name in heading_tags:
                            chunk.append(para)
                            chunks.append(chunk)
                            level = int(all_tags[t + 1].name[1:])
                            chunk = chunk[:level]
                            para = ""
                    if t == len(all_tags) - 1:
                        chunk.append(para)
                        chunks.append(chunk)
        elif doc_type in ['.pptx']:
            filename = doc_path + '\\' + document_name
            with open(filename, 'rb') as file:
                files = {'file': file}
                json_data = requests.post(tika_url, files=files, proxies={'http': 'http://10.135.0.29:8080'}).json()
                html_file = json_data['htmlFileTag']
                soup = BeautifulSoup(html_file, 'html.parser')
                div2 = soup.findAll("div", {"class": "slide-content"})
                for x in div2:
                    chunk = []
                    chunk.append(document_name)
                    no_of_p = len(x.find_all('p'))
                    for i in range(0, no_of_p):
                        p_tags = x.findAll('p')[i].get_text()
                        chunk.append(p_tags)
                    chunks.append(chunk)
        elif doc_type in ['.pdf']:
            filename = os.path.join(doc_path, document_name)
            url = "https://ontologydcsfrominputstream.azurewebsites.net/DocumentConversion/v1/json"
            with open(filename, 'rb') as file:
                chunks = []
                files = {'file': file}
                json_data = requests.post(url, files=files, proxies={'http': 'http://10.135.0.29:8080'}).json()
                html_file = json_data['htmlFileTag']
                soup = BeautifulSoup(html_file, 'html.parser')
                div2 = soup.findAll('div', style=("page-break-before:always; page-break-after:always"))
                for x in div2:
                    chunk = []
                    chunk.append(document_name)
                    no_of_p = len(x.find_all('p'))
                    for i in range(0, no_of_p):
                        p_tags = x.findAll('p')[i].get_text()
                        chunk.append(p_tags)
                        chunk = [x.strip(' ') for x in chunk]
                        chunk = [x.strip('') for x in chunk]
                        chunk = [x.strip('\n') for x in chunk]
                        chunk = [x.strip('\r') for x in chunk]
                        chunk = [x.strip('\r\n') for x in chunk]
                        chunk = [x for x in chunk if x]
                    chunks.append(chunk)
        elif doc_type in ['.xlsx']:
            filename = doc_path + '\\' + document_name
            url = "https://ontologydcsfrominputstream.azurewebsites.net/DocumentConversion/v1/json"
            with open(filename, 'rb') as file:
                chunks = []
                files = {'file': file}
                json_data = requests.post(url, files=files, proxies={'http': 'http://10.135.0.29:8080'}).json()
                html_file = json_data['htmlFileTag']
                soup = BeautifulSoup(html_file, 'html.parser')
                div2 = soup.findAll('div')
                for i in div2:
                    chunk = []
                    chunk.append(document_name)
                    h_tags = i.find('h1').get_text()
                    soup.h1.decompose()
                    chunk.append(h_tags)
                    chunk.append(i)
                    chunks.append(chunk)
        output_data.extend(chunks)
    all_answers = output_data
    return all_answers

def create_tfid(incident_description_clean):
    tf_idf_vect = TfidfVectorizer(stop_words=None)
    final_tf_idf = tf_idf_vect.fit_transform(incident_description_clean)
    tfidf_feat = tf_idf_vect.get_feature_names()
    return tf_idf_vect,final_tf_idf,tfidf_feat

def tfid_boost_vectors(text,model,final_tf_idf,tfidf_feat):
    tfidf_sent_vectors = [];
    row=0;
    errors=0
    for sent in text:
        sent_vec = np.zeros(200)
        weight_sum =0;
        for word in sent:
            try:
                if word in model.wv.vocab:
                    vec = model.wv[word]
                    tfidf = final_tf_idf [row, tfidf_feat.index(word)]
                    sent_vec += (vec * tfidf)
                    weight_sum += tfidf
                else:
                    sim_list = model.wv.similar_by_word(word,100)
                    if int(sim_list[0][1]*100)> 68:
                        vec = model.wv[word]
                        tfidf = final_tf_idf[row, tfidf_feat.index(word)]
                        sent_vec += (vec * tfidf)
                        weight_sum += tfidf
            except:
                errors =+1
                pass
        sent_vec /= weight_sum
        tfidf_sent_vectors.append(sent_vec)
        row += 1
    return tfidf_sent_vectors

def tokenizing_sent(sent_list):
    text = []
    for sent in sent_list:
        tokens = [words for words in sent.split()]
        text.append(tokens)
    return text


def deEmojify(inputString):
    return inputString.encode('ascii', 'ignore').decode('ascii')

def create_sentence_embeding(data):
    doc_path = os.getcwd() + '/documents'
    if os.path.exists(doc_path) and len(os.listdir(doc_path)) != 0:
        doc_text=get_documents_data()
        raw_data = []
        if doc_text != "":
            for i in doc_text:
                sentstr = ''
                for x in i:
                    sentstr += str(x) + " "
                raw_data.append(sentstr.rstrip())
    incident_description_list=data['Cleaned_Notes'].tolist()
    incident_description_list = clean_text_old(incident_description_list)
    incident_description_clean=incident_description_list

    if os.path.exists(doc_path) and len(os.listdir(doc_path))!=0:
        final_data = raw_data + incident_description_clean
    else:
        final_data=incident_description_clean
    sentences = []
    for sen in final_data:
        words = sen.split()
        sentences.append(words)
    model,train_embedding=create_fasttext_model(sentences,incident_description_clean)
    tf_idf_vect, final_tf_idf, tfidf_feat = create_tfid(incident_description_clean)
    text = tokenizing_sent(incident_description_clean)
    tfidf_sent_vectors = tfid_boost_vectors(text, model, final_tf_idf, tfidf_feat)
    model_base = os.getcwd()+"/models/"
    with open(model_base +  'fasttext_bit_keywords_list.features', "wb") as f:
        pickle.dump(train_embedding, f)
    with open(model_base +  'fasttext_bit_keywords_list.model', "wb") as f:
        pickle.dump(model, f)
    with open(model_base +  'tfid_feat_list.features', "wb") as f:
        pickle.dump(tfidf_feat, f)
    with open(model_base +  'train_tfid.features', "wb") as f:
        pickle.dump(tfidf_sent_vectors, f)
    with open(model_base +  'tfid.features', "wb") as f:
        pickle.dump(tf_idf_vect, f)

def create_fasttext_model(sentences,incident_description):
    model = FastText(sg=1, size=200, window=16, min_count=1, iter=100, cbow_mean=0, sorted_vocab=0, workers=4,
                     batch_words=1000)
    model.build_vocab(sentences=sentences)
    model.train(sentences=sentences, total_examples=model.corpus_count, epochs=100)
    train_embedding = model.wv[incident_description]
    return model,train_embedding

def cleaning_keywords(keywords):
  keywords =   [keyword for keyword in keywords if
                str(keyword)!='nan']
  keywords = [words.strip() for keywo in keywords for words in keywo.split(',') if
                                   words.strip() != ""]
  return keywords

def clean_keyword(incident_keyword_list):
    cleaned_keywords=[]
    for sent_str in incident_keyword_list:
        modified_string = ' '.join([word for word in sent_str.split() if word not in (stopwords.words('english'))])
        modified_string = ' '.join([w for w in modified_string.split() if len(w)>3])
        cleaned_keywords.append(modified_string)
    keywords_list_clean=[]
    for keyword in cleaned_keywords:
        keywords_separated=keyword.split(",")
        for ke in keywords_separated:
            if ke not in keywords_list_clean:

                keywords_list_clean.append(ke.strip())

            else:
                pass
    keywords_list_clean = list(filter(None, keywords_list_clean))
    keyword_set=list(set(keywords_list_clean))
    return keyword_set

def deEmojify(inputString):
    return inputString.encode('ascii', 'ignore').decode('ascii')


def clean_text_old(incident_solution_list):
    new_solution = []
    for sentences in incident_solution_list:
        text = re.sub('Environment : Global \(WW\) or TBU', ' ', sentences)

        text = re.sub('Instance : Production, Acceptance, Development, PRODUCTION\.\.\.', ' ', text)
        text = re.sub('\(Example : VD3, VT3, VP3, VDS, VRS, VPS, AD6, AC6, AQ6, PA6, \.\.\.\.\)', ' ', text)
        text = re.sub('Impact : Is this a problem only for the user or general \(more business users\) ', ' ', text)
        text = re.sub('Date and time recorded from the beginning of the dysfunction if pb general', ' ', text)
        text = re.sub('What is the SAP processes \? ', ' ', text)
        text = re.sub('References \(example : No order\/invoice\/receipt\/supplier\/item Code\/.......\)', ' ', text)
        text = re.sub(
            'Precise Description of the anomaly found : a message of anomaly, or blocking,or dump, or description of the problem \.\.\.\.\.',
            ' ', text)
        text = re.sub('A copy of screen by WADP, or by sending mail to user', ' ', text)
        text = re.sub(
            'If pb d printing : what type of form \(Ex : Edit of an order, an invoice, a delivery note , \.\.\.\.\.\.\)',
            ' ', text)
        text = re.sub('The name of the SAP transaction to use', ' ', text)
        text = re.sub('Impact: Is this a problem only for the general user gold general \(multiple business users\)',
                      ' ', text)
        text = re.sub('Date and time of start of the issue if it is a general issue', ' ', text)
        text = re.sub(
            'References \(example: order no.\/invoice no.\/receipt no\.\/vendor no\.\/Part number\/\.\.\.\.\)', ' ',
            text)
        text = re.sub(
            'Specific description of the defect encountered : defect, blocking gold dump message gold problem description\.\.\.\.',
            ' ', text)
        text = re.sub('Screen shot by WADP or by mail sent by the user', ' ', text)
        text = re.sub(
            '(Steps for Incident replication with Screen shots|Service|Model|Impact|Category|Sub-category|Group d assignment|Assigned to|Template|Work instruction|Information to redirect the incident to the correct stakeholder|Start Date \/ time|End Date \/ time|Code flow|Treatment parameters|Id processing|Name of file to process|Information for the redirection of the incident to the relevant person)\s{0,3}:',
            ' ', text)
        text = re.sub(
            '(In case of printing problem, the form type \(E\.g\.: Printer Identification number, printing of an order, invoice, delivery note etc\.\)|SAP document references|Treatment group|TMA|Impact|Category|Server|Application|Client|Customer impact|Location|Libell\?|Incident|Type of problem|Service environment|Graph Vega|Warning|Description|Criticit\?|P\?period|SAP transaction \/ BI report name used)\s{0,3}:',
            ' ', text)
        text = re.sub('Which production instance \(Example: PEC, PBW, PGR, PSO, BEC, BBW\)\?', ' ', text)
        text = re.sub('TGI of the user who encountered the problem in the production environment\?', ' ', text)
        text = re.sub('What is the (actual|expected) value, behaviour or result\?', ' ', text)
        text = re.sub('\(Example: Order number\/Invoice number\/Receipt number\/Vendor number\/Part number\/etc.\)',
                      ' ', text)
        text = re.sub(
            '\(Describe steps - including Transaction code - carried out prior to malfunction observed with input values in each step \[if applicable\]\. Screen-shots of steps with description and code of the blocking message\)',
            ' ', text)
        text = re.sub('Can the issue be reproduced in test environment\?', ' ', text)
        text = re.sub(
            'Is the problem specific only to the user or is it a general problem \(several users impacted\)\?', ' ',
            text)
        text = re.sub('Date and time when the malfunction was first observed \(in case of general problem\)\?', ' ',
                      text)
        text = re.sub('\(Example: Order number\/Invoice number\/Receipt number\/Vendor number\/Part number\/etc.\)',
                      ' ', text)
        text = re.sub('\(Example: Order number\/Invoice number\/Receipt number\/Vendor number\/Part number\/etc.\)',
                      ' ', text)
        text = re.sub('\n', ' ', text)
        text = re.sub('IND', ' ', text)
        text = re.sub('KPS', ' ', text)
        text = re.sub('French to English translation?\s{0,10}:', ' ', text)
        text = re.sub('[IiE]N [Tt]ranslation\s{0,10}?:', ' ', text)
        text = re.sub('Short description\s{0,10}?:', ' ', text)
        text = re.sub('English to French translation\s{0,10}?:', ' ', text)
        text = re.sub('EN to FR Translation\s{0,10}?:', ' ', text)
        text = re.sub('FR to EN Translation:\s{0,10}?:', ' ', text)
        text = re.sub(r'https?:\/\/.*[\r\n]*', '', text, flags=re.MULTILINE)
        text = re.sub('  ', ' ', text)
        text = deEmojify(text)
        text = re.sub('[^A-Za-z0-9]+', ' ', text)
        new_solution.append(text)
    return new_solution

def filter_empty(new_incidents):
    new_incidents = filter(None, new_incidents)
    new_incidents = filter(bool, new_incidents)
    new_incidents = filter(len, new_incidents)
    new_incidents = filter(lambda item: item, new_incidents)
    new_incidents = list(filter(None, new_incidents))
    return new_incidents

def clean_doc(doc):
    punctuations = "!#$%&\'()*,:;<=>?[\\]^`{|}~?." + '"'
    regex = '^(?=.*[0-9])([a-zA-Z0-9]+)$'
    stopword_list = ['me', 'my', 'we', 'he', 'it', 'am', 'is', 'be', 'do', 'an', 'if', 'or', 'as', 'of', 'at', 'by',
                     'to', 'up', 'in', 'on', 'no', 'so']
    """
    Cleaning a document by several methods
    """
    doc = doc.lower()
    doc = re.sub('(first name, last name:[\\s\\S][A-Za-z ]*)', '', doc)
    doc = re.sub('([Uu]ser [Ii][dD][.]*:[\\s\\S][A-Za-z0-9 ]*)', '', doc)
    doc = re.sub('(Name[.]*:[\\s\\S][A-Za-z0-9 ]*)', '', doc)
    doc = re.sub('([Ee]mail [Aa]ddress:[ ]*[A-Za-z0-9._]*@[[A-Za-z0-9._]*)', '', doc)
    doc = re.sub('(Name[.]*:[ ]*[A-Za-z ]+)', '', doc)
    doc = re.sub('(Phone[.]*:[ ]*[A-Za-z0-9 +/(/)]*)', '', doc)
    doc = re.sub('([Pp]hone[.]*[ ]*[\\S]*[.]*:[ ]*[A-Za-z0-9 +/(/):]*)', '', doc)
    doc = re.sub('([mM]obile:[ +0-9]*)', '', doc)
    tokens_dirty = doc.split()
    tokens = []
    for dirty_token in tokens_dirty:
        if str(dirty_token).startswith('$'):
            continue
        if len(dirty_token) < 3 and str(dirty_token).isnumeric():
            continue
        if len(dirty_token) > 1 and dirty_token[-1] == ".":
            dirty_token = dirty_token[:-1]
        if len(dirty_token) < 10:
            dirty_token = dirty_token.translate(str.maketrans('', '', punctuations))
        token = dirty_token.strip(punctuations)
        token = token.lstrip(punctuations)
        if len(set(token)) < 2:
            continue
        if re.match(regex, token):
            continue
        if len(token) > 2 or token in stopword_list:
            tokens.append(token)
    tokens = [word for word in tokens if len(word) > 1]
    return tokens

def read_files(cleaned_notes):
    documents = list()
    for doc in cleaned_notes:
        doc = clean_doc(doc)
        documents.append(' '.join(doc))
    return documents

train_filepath = os.getcwd() +"/ERP_manufacturing.xlsx"
inputfile_df = pd.read_excel(train_filepath)
columns = inputfile_df.columns.tolist()

cleaned_notes = inputfile_df['Incident description'].tolist()

inputfile_df['Cleaned_Notes'] = read_files(cleaned_notes)

create_sentence_embeding(inputfile_df)


