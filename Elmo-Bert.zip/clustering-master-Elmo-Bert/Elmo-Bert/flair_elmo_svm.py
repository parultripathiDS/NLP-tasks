# -*- coding: utf-8 -*-



import pandas as pd
from flair.models import TextClassifier
from flair.data import Sentence

from flair.embeddings import WordEmbeddings
from flair.embeddings import CharacterEmbeddings
from flair.embeddings import StackedEmbeddings, DocumentLSTMEmbeddings
from flair.embeddings import FlairEmbeddings
from flair.embeddings import BertEmbeddings
from flair.embeddings import ELMoEmbeddings
from flair.embeddings import FlairEmbeddings
from flair.data_fetcher import NLPTaskDataFetcher
from pathlib import Path
import numpy as np
from sklearn import svm
import numpy as np
from flair.embeddings import WordEmbeddings, FlairEmbeddings, StackedEmbeddings
from flair.embeddings import ELMoEmbeddings
from sklearn import preprocessing
#pip install flair

#pip install allennlp

df = pd.read_csv('data_flair_train.csv', encoding = 'ISO-8859-1')

x = df['x'].values.tolist()
y = df['y'].values.tolist()


le = preprocessing.LabelEncoder()
y_labels = le.fit_transform(y)

def get_integer_mapping(le):
    res = {}
    for cl in le.classes_:
        res.update({cl:le.transform([cl])[0]})

    return res

integerMapping = get_integer_mapping(le)







embedding = ELMoEmbeddings()


x_train = []   
sent =x
for i in sent:
         sentence = Sentence(str(i))
         embedding.embed(sentence)
         sent_vec =[]
         numw = 0
         for token in sentence:
             try:
                 if numw == 0:
                     sent_vec = token.embedding.tolist()
                 else:
                     sent_vec = np.add(sent_vec, token.embedding.tolist())
                 numw+=1
             except:
                 pass
              
         final_value = np.asarray(sent_vec) / numw
         x_train.append(final_value)
         print(len(x_train))


train_x = np.asarray(x_train)
train_y = np.asarray(y_labels)


svc = svm.SVC(kernel='rbf', C=1).fit(train_x, train_y)





test=pd.read_csv('NHS_May.csv', encoding="ISO-8859-1")
test=test['extracted_problem'].values.tolist()
str_test=[]
for i in test:
  str_test.append(str(i))


x_test = []   
sent =str_test
for i in sent:
         sentence = Sentence(str(i))
         embedding.embed(sentence)
         sent_vec =[]
         numw = 0
         for token in sentence:
             try:
                 if numw == 0:
                     sent_vec = token.embedding.tolist()
                 else:
                     sent_vec = np.add(sent_vec, token.embedding.tolist())
                 numw+=1
             except:
                 pass
              
         final_value = np.asarray(sent_vec) / numw
         x_test.append(final_value)
         print(len(x_test))

x_test = np.asarray(x_test)
y_test=svc.predict(x_test)
y_test=np.array(y_test).tolist()
for i in range(0,len(y_test)):
  for k,v in integerMapping.items():
    if y_test[i] == v:
       y_test[i] = k

